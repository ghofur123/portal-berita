   <footer>
       <!-- Footer Start-->
       <div class="footer-area footer-padding fix">
            <div class="container">
                <div class="row d-flex justify-content-between">
                    <div class="col-xl-5 col-lg-5 col-md-7 col-sm-12">
                        <div class="single-footer-caption">
                            <div class="single-footer-caption">
                                <!-- logo -->
                                <div class="footer-logo">
                                    <a href="index.html"><img src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/img/logo/logo-suara-indonesia-google-news.png" alt=""></a>
                                </div>
                                <div class="footer-tittle">
                                    <div class="footer-pera">
                                        <p>Media Nasional Berjaringan suaraindonesia.co.id adalah media mainstream yang sudah memiliki legalitas resmi Kemenkumham dan Terverifikasi Faktual Dewan Pers</p>
                                    </div>
                                </div>
                                <!-- social -->
                                <div class="footer-social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                    <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-4  col-sm-6">
                        <div class="single-footer-caption mt-60">
                            <div class="footer-tittle">
                                <h4>Berlangganan Berita</h4>
                                <p>untuk dapat berlangganan berita terbaru kami lewat email </p>
                                <!-- Form -->
                                <div class="footer-form" >
                                    <div id="mc_embed_signup">
                                        <form target="_blank" action="#"
                                        method="get" class="subscribe_form relative mail_part">
                                            <input type="email" name="email" id="newsletter-form-email" placeholder="Email Address"
                                            class="placeholder hide-on-focus" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ' Email Address '">
                                            <div class="form-icon">
                                            <button type="submit" name="submit" id="newsletter-submit"
                                            class="email_icon newsletter-submit button-contactForm">Kirim</button>
                                            </div>
                                            <div class="mt-10 info"></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-5 col-sm-6">
                        <div class="single-footer-caption mb-50 mt-60">
                            <div class="footer-tittle">
                                <h4>Pages</h4>
                            </div>
                            <div>
                                <ul class="pages-footer">
                                    <!-- pages footer -->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   </footer>
   
	<!-- JS here -->
	
		<!-- All JS Custom Plugins Link Here here -->
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/vendor/modernizr-3.5.0.min.js"></script>
		<!-- Jquery, Popper, Bootstrap -->
		<script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/vendor/jquery-1.12.4.min.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/popper.min.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/bootstrap.min.js"></script>
	    <!-- Jquery Mobile Menu -->
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/jquery.slicknav.min.js"></script>

		<!-- Jquery Slick , Owl-Carousel Plugins -->
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/owl.carousel.min.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/slick.min.js"></script>
        <!-- Date Picker -->
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/gijgo.min.js"></script>
		<!-- One Page, Animated-HeadLin -->
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/wow.min.js"></script>
		<script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/animated.headline.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/jquery.magnific-popup.js"></script>

        <!-- Breaking New Pluging -->
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/jquery.ticker.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/site.js"></script>

		<!-- Scrollup, nice-select, sticky -->
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/jquery.scrollUp.min.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/jquery.nice-select.min.js"></script>
		<script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/jquery.sticky.js"></script>
        
        <!-- contact js -->
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/contact.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/jquery.form.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/jquery.validate.min.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/mail-script.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/jquery.ajaxchimp.min.js"></script>
        
		<!-- Jquery Plugins, main Jquery -->	
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/plugins.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/main.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/beranda.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/navigation.js"></script>
        <script src="<?php base_url(); ?><?php base_url(); echo $url_segment; ?>assets/usr2/js/fokusberita.js"></script>
        
    </body>
</html>