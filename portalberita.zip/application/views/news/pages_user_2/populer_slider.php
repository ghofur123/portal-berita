    <!--   Weekly-News start -->
    <div class="weekly-news-area pt-50">
        <div class="container">
           <div class="weekly-wrapper">
                <!-- section Tittle -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-tittle mb-30">
                            <h3>Populer</h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="pupuler-class-view weekly-news-active dot-style d-flex dot-style">

                            <div class="weekly-single">
                                <div class="weekly-img">
                                    <img class="img-slide-bootom-0" src="" alt="">
                                </div>
                                <div class="weekly-caption">
                                    <span class="kategori-slide-bootom-0 color1"></span>
                                    <span class="tgl-class-popler-0"></span>
                                    <h4><a href="#" class='judul-slide-bootom-0'></a></h4>
                                </div>
                            </div> 

                            <div class="weekly-single">
                                <div class="weekly-img">
                                    <img class="img-slide-bootom-1" src="" alt="">
                                </div>
                                <div class="weekly-caption">
                                    <span class="kategori-slide-bootom-1 color1"></span>
                                    <span class="tgl-class-popler-1"></span>
                                    <h4><a href="#" class='judul-slide-bootom-1'></a></h4>
                                </div>
                            </div>

                            <div class="weekly-single">
                                <div class="weekly-img">
                                    <img class="img-slide-bootom-2" src="" alt="">
                                </div>
                                <div class="weekly-caption">
                                    <span class="kategori-slide-bootom-2 color1"></span>
                                    <span class="tgl-class-popler-2"></span>
                                    <h4><a href="#" class='judul-slide-bootom-2'></a></h4>
                                </div>
                            </div>

                            <div class="weekly-single">
                                <div class="weekly-img">
                                    <img class="img-slide-bootom-3" src="" alt="">
                                </div>
                                <div class="weekly-caption">
                                    <span class="kategori-slide-bootom-3 color1"></span>
                                    <span class="tgl-class-popler-3"></span>
                                    <h4><a href="#" class='judul-slide-bootom-3'></a></h4>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
           </div>
        </div>
    </div>           
    <!-- End Weekly-News -->