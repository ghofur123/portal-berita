<main>
        <!-- About US Start -->
        <div class="about-area">
            <div class="container">
                   <div class="row">
                        <div class="col-lg-12">
                            <!-- Trending Tittle -->
                            <div class="about-right mb-90">
                                <!-- <div class="about-img">
                                    <img class='img-detail-class' src="" alt="">
                                </div> -->
                                <div class="section-tittle mb-30 pt-30 ">
                                    <h3 class='title-pages-class'></h3>
                                    <!-- <h6 class="tgl-detail-class"></h6> -->
                                </div>
                                <div class="deskription-class-pages about-prea">
                                </div>
                                <!-- <div class="link-terkait-class about-prea">
                                </div> -->
                            </div>
                        </div>
                   </div>
            </div>
        </div>
        <!-- About US End -->
    </main>