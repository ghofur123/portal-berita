<main>
        <!-- About US Start -->
        <div class="about-area">
            <div class="container">
                   <div class="row">
                        <div class="col-lg-8">
                            <!-- Trending Tittle -->
                            <div class="about-right mb-90">
                                <div class="about-img">
                                    <img class='img-detail-class' src="" alt="">
                                </div>
                                <div class="section-tittle mb-30 pt-30 ">
                                    <h3 class='title-detail-class'></h3>
                                    <h6 class="tgl-detail-class"></h6>
                                </div>
                                <div class="deskription-class about-prea">
                                </div>
                                <div class="link-terkait-class about-prea">
                                </div>
                                <div class="social-share pt-30">
                                    <div class="section-tittle">
                                        <h3 class="mr-20">Share:</h3>
                                        <ul>
                                            <li><a href="#"><img src="<?php base_url(); ?>../../assets/usr2/img/news/icon-ins.png" alt=""></a></li>
                                            <li><a href="#"><img src="<?php base_url(); ?>../../assets/usr2/img/news/icon-fb.png" alt=""></a></li>
                                            <li><a href="#"><img src="<?php base_url(); ?>../../assets/usr2/img/news/icon-tw.png" alt=""></a></li>
                                            <li><a href="#"><img src="<?php base_url(); ?>../../assets/usr2/img/news/icon-yo.png" alt=""></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!-- From -->
                            <div class="row">
                                <div class="col-lg-8">
                                    <form class="form-contact contact_form mb-80" action="contact_process.php" method="post" id="contactForm" novalidate="novalidate">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <textarea class="form-control w-100 error" name="message" id="message" cols="30" rows="9" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Message'" placeholder="Enter Message"></textarea>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <input class="form-control error" name="name" id="name" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter your name'" placeholder="Enter your name">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <input class="form-control error" name="email" id="email" type="email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter email address'" placeholder="Email">
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <input class="form-control error" name="subject" id="subject" type="text" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Subject'" placeholder="Enter Subject">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group mt-3">
                                            <button type="submit" class="button button-contactForm boxed-btn">Send</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4">

                            <div class="section-tittle mb-40">
                                <h3>Fokus Berita</h3>
                            </div>
                            <div class="single-follow mb-45">
                                <div class="list-group">
                                </div>
                            </div>
                            <div class="blog_right_sidebar">
                                <aside class="right-content-singgle single_sidebar_widget popular_post_widget">  
                                </aside>
                            </div>
                        </div>
                   </div>
            </div>
        </div>
        <!-- About US End -->
    </main>