        <script src="<?php base_url(); echo $url_segment; ?>assets/usr2/js/navigation.js"></script>
        <script src="<?php base_url(); echo $url_segment; ?>assets/usr2/js/custemjs/pages.js"></script>
    </body>
</html>