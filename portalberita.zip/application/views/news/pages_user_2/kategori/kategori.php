
       <section class="whats-news-area pt-50 pb-20">
        <div class="container">
            <div class="row">
            <div class="col-lg-8">
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-1 col-md-3">
                        <div class="section-tittle mb-30">
                            <h3>Kategori</h3>
                        </div>
                    </div>
                </div>
                <div class="row d-flex justify-content-between">
                    <div class="col-lg-11 col-md-9">
                            <div class="properties__button">
                                <!--Nav Button  -->                                            
                                <nav>                                                                     
                                    <div class="cls-nav-item-data nav nav-tabs" id="nav-tab" role="tablist">
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                <div class="row">
                    <div class="col-12">
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">           
                                <div class="whats-news-caption">
                                    <div class="row terbaru-berita-class">
                                        <!-- kategori -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="section-tittle mb-40">
                    <h3>Fokus Berita</h3>
                </div>
                <div class="single-follow mb-45">
                    <div class="list-group">
                    </div>
                </div>
                <div class="news-poster d-none d-lg-block">
                    <img src="<?php base_url(); ?>./../assets/usr2/img/news/news_card.jpg" alt="">
                </div>
            </div>
            </div>
        </div>
    </section>
    <div class="pagination-area pb-45 text-center">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="single-wrap d-flex justify-content-center">
                        <nav aria-label="Page navigation example">
                            <ul class="pagination justify-content-start">
                              <li class="page-item"><span class="flaticon-arrow roted"></span></li>
                                <li class="class-muat-lebih page-item active">Muat Lebih Banyak</li>
                              <li class="page-item"><span class="flaticon-arrow right-arrow"></span></li>
                            </ul>
                          </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
