<nav class="navbar-default navbar-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav menu-load-db" id="main-menu">
        </ul>
    </div>

</nav>
<div id="page-wrapper">
    <div id="page-inner">
        <div class='progress'>
            <div class='progress-bar progress-bar-danger progress-bar-striped active'  role='progressbar' aria-valuenow='100' aria-valuemin='0' aria-valuemax='100' style='width: 100%'>
                <span class='sr-only'>proses</span>
            </div>
        </div>
        <div class="class-view-content-all"></div>