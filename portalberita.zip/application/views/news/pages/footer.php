            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    
    </div>
    <!-- /. WRAPPER  -->
    <div id="footer-sec">
        &copy; 2022 beirta jatim | Design By : <a href="#" target="_blank">beritajatim.com</a>
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    <!-- quils -->
    <script src="<?php base_url(); ?>../assets/js/bootstrap.js"></script>
     <!-- METISMENU SCRIPTS -->
    <script src="<?php base_url(); ?>../assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="<?php base_url(); ?>../assets/js/custom.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="<?php base_url(); ?>../assets/js/news/menu.js"></script>
    <!-- ckeditor -->
    <script src="https://cdn.ckeditor.com/4.18.0/standard/ckeditor.js"></script>

    <!-- datatables -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap.min.js"></script>
    

</body>
</html>