<div class='banner-top-thumb-wrap'>
  <div class='content-value-cls d-lg-flex justify-content-between align-items-center '>
    
</div>
</div>