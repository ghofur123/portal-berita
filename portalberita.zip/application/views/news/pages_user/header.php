<!DOCTYPE html>
<html lang="zxx">
  <head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>World Vision</title>
    <!-- plugin css for this page -->
    <link
      rel="stylesheet"
      href="<?php base_url(); ?>./assets/usr/vendors/mdi/css/materialdesignicons.min.css"
    />
    <link rel="stylesheet" href="<?php base_url(); ?>./assets/usr/vendors/aos/dist/aos.css/aos.css" />
    <link
      rel="stylesheet"
      href="<?php base_url(); ?>./assets/usr/vendors/owl.carousel/dist/assets/owl.carousel.min.css"
    />
    <link
      rel="stylesheet"
      href="<?php base_url(); ?>./assets/usr/vendors/owl.carousel/dist/assets/owl.theme.default.min.css"
    />
    <!-- End plugin css for this page -->
    <link rel="shortcut icon" href="<?php base_url(); ?>./assets/usr/images/favicon.png" />
    <!-- inject:css -->
    <link rel="stylesheet" href="<?php base_url(); ?>./assets/usr/css/style.css">
    <!-- endinject -->
    <link rel="stylesheet" href="<?php base_url(); ?>./assets/usr/css/st.css">

  </head>
  <body>
    <div class="container-scroller">
      <div class="main-panel">