<form action='#' class='form-menu_access-1649233502984'>
    <input type='text' name='uniq_menu_access' class='uniq_menu_access' placeholder='menu_access' hidden />
    <input type='text' name='user_id' class='user_id' placeholder='user_id' />
    <input type='text' name='menu_id' class='menu_id' placeholder='menu_id' />
    <input type='text' name='create' class='create' placeholder='create' />
    <input type='text' name='read' class='read' placeholder='read' />
    <input type='text' name='update' class='update' placeholder='update' />
    <input type='text' name='delete' class='delete' placeholder='delete' />
    <button type='submit' class='btn-menu_access-insert-class'>Save</button>
</form>
<div class='class-menu_access-view-edit-data'></div>
<div class='class-menu_access-view-data'></div>
<script src="../assets/js/news/pages/menu_access.js"></script>