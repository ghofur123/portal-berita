
<div class='col-md-12 form-input-class-all'>
    <div class='panel panel-primary'>
        <div class='panel-heading'>
            Menu
        </div>
        <div class='panel-body'>
        
        <div class="class-form-input-card"></div>
        </div>
        <div class='panel-footer'>
        </div>
    </div>
</div>
<div class='class-menu-view-edit-data'></div>

<div class='row data-table-rows-all'>
	<div class='col-md-12'>
		<div class='panel panel-default'>
			<div class='panel-heading form-inline'>
				<button type='button' class='btn-new-data btn btn-primary'>New</button>
            </div>
			<div class='panel-body'>
				<div class='table-responsive'>
					<div class='class-menu-view-data'></div>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="../assets/js/news/pages/menu.js"></script>