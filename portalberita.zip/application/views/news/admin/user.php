<button type='button' class='btn-new-data btn btn-primary'>New</button>
<div class='col-md-12 form-input-class-all'>
    <div class='panel panel-primary'>
        <div class='panel-heading'>
            user
        </div>
        <div class='panel-body'>
        
        <div class="class-form-input-card"></div>
        </div>
        <div class='panel-footer'>
        </div>
    </div>
</div>
<div class='class-user-view-edit-data'></div>
<div class='class-user-view-data'></div>
<script src="../assets/js/news/pages/user.js"></script>